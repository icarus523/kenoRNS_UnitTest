import os
import subprocess

KEYPATH = "keys"
cmd = "python3 bin/ksignaudit.py"

class get_cmd():

    def __init__(self):
        signkey_list = [x for x in os.listdir(KEYPATH) if x.endswith('.pem')]
        self.process_files(signkey_list)

    def process_files(self, k_list):
        for filename in k_list:
            output_str = cmd + " -s " + os.path.join(KEYPATH, filename)

            subprocess.call(output_str, shell=True)

def main():
    app = get_cmd()

if __name__ == "__main__": main()
