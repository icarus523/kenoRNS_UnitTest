# ksignaudit.py
#
#
##
##  Usage:
##       ksignaudit.py -s sign1 -s sign2
##
##
##  To check signature json result and parameters check
##  Result: Keno draw ID ----- FAIl or PASS or None
##
##
# Version History
# v1.0 - Initial Release    DN
# v1.1 - Update to add checking for parameters
# v1.2 - Updated to Python3 and fixed formatting
import os
import sys, getopt
import subprocess
import json
import xml.etree.ElementTree as etree
from xml.etree.ElementTree import ElementTree

# This needs to change if required.
RNS2_RESULTS_PATH = "rns2_results_unzipped"

def list_files(path, filetypestr):
    # returns a list of names (with extension, without full path) of all files
    # in folder path
    files = []

    for name in os.listdir(path):
        if os.path.isfile(os.path.join(path, name)):
            if name.endswith(filetypestr):
                files.append(os.path.join(path,name))
    return files

def cat_signlogfile(filenames):
    with open('signlog.txt', 'w') as outfile:
        for fname in filenames:
            outfile.write("Check signature for file : " + fname + "\n")
            with open(fname) as infile:
                for line in infile:
                    outfile.write(line)
            os.remove(fname)

def logstringtofile(stringnames):
    with open('signparalog.out', 'a+') as outfile:
        outfile.write("\n" + stringnames + "\n")

def run_jav(file,signing_key):
    subprocess.call('java -jar bin/KenoSignAudit.jar ' + file +  ' ' + signing_key + ' > ' + file +'_signlog.out', shell=True)
    # pid = subprocess.Popen(args=['cmd.exe', '--command=java']).pid

def parametercheck(resultsJsonFile):
    # json_file_data = open(os.path.join(RNS2_RESULTS_PATH,resultsJsonFile))
    # with open(resultsJsonFile, 'r') as f:
    json_file_data = open(resultsJsonFile)
    json_data = json.load(json_file_data) # resultsJsonFile)

    for result in json_data['results']:
        KenoID = result['result']['resultId']
        resultXml = etree.fromstring(result['result']['result'].encode('utf-8'))
        for child in resultXml:
            # print(child.tag, child.attrib)
            jsrel = child.findtext('{urn:envelope}results')
            jpara = child.find('{urn:envelope}parameters')
            jnumset = jpara.findtext('{urn:envelope}numberOfSets')
            #print(jnumset)
            if (int(jnumset) != 1):
                logstringtofile("Keno ID : " + KenoID + " Result check numberOfSets:  FAIL ")
            jcount = jpara.findtext('{urn:envelope}count')
            #print(jcount)
            if (int(jcount) != 20):
                logstringtofile("Keno ID : " + KenoID + " Result check count: FAIL ")

            jrange = jpara.findall('{urn:envelope}range')
            #print("range ; ", " ".join(jrange))

            # check range parameters
            for item in jrange:
                for k,v in item.attrib.items():
                    #print(k, v)
                    if (k=="max" and (int(v) !=80)):
                        logstringtofile("Keno ID : " + KenoID + " Result check range max: FAIL ")
                    if (k=="min" and (int(v) !=1)):
                        logstringtofile("Keno ID : " + KenoID + " Result check range min: FAIL ")

            jreplacement = jpara.findtext('{urn:envelope}replacement')
            #print(jreplacement)
            if (jreplacement != "false"):
                logstringtofile("Keno ID : " + KenoID + " Result check replacement: FAIL ")

            jweighting= jpara.findtext('{urn:envelope}weighting')
            #print("weigth: ", jweighting)
            if (jweighting is not None):
                logstringtofile("Keno ID : " + KenoID + " Result check weighting: FAIL ")
            jsver = child.find('{urn:envelope}verificationContext')
            jsgnum = jsver.findtext('{urn:envelope}gameNumber')
            jsgnrel = str(int(jsgnum)) + "," + jsrel
            if(jsrel !=0):
                break

def printUsage():
    print('ksignaudit.py -s <signkey1.pem> -s <signkey2.pem>')

class signaturecheck():

    def __init__(self):
        signfile = ''
        try:
            opts, args = getopt.getopt(sys.argv[1:],"s:h",["sign="])
        except getopt.GetoptError:
            printUsage()
            sys.exit(2)

        for opt, arg in opts:
            if opt in ("-s", "--sign"):
                signfile = signfile + ' ' + arg
            else:
                printUsage()
                sys.exit(2)

        # check no signature certificate
        if(not signfile):
            printUsage()
            sys.exit(2)

        # get current directory.
        filejson_lists = list_files(RNS2_RESULTS_PATH, ".json")

        # Process cross check signature for all json file
        for f in filejson_lists:
            print("Verify signature and parameters for json file: " + f + signfile +"\n")
            # print("signature file: " + signfile +"\n")
            run_jav(f,signfile)
            parametercheck(f)

        # cat all .out file in logevent file
        fileout_lists = list_files(RNS2_RESULTS_PATH, ".out")
        cat_signlogfile(fileout_lists)

def main():
#   sign cross check
    app  = signaturecheck()

if __name__ == "__main__": main()
